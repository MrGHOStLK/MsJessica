/* Codded by @phaticusthiccy
Telegram: t.me/phaticusthiccy
Instagram: www.instagram.com/kyrie.baran
*/

// It converts wrong commands to true
// Also Kind of AI 

const Asena = require('../events');
const {MessageType, GroupSettingChange} = require('@adiwajshing/baileys');

Asena.addCommand({pattern: 'udpate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: 'hi', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    

    await message.sendMessage('Hello!');

}));

Asena.addCommand({pattern: 'udpste', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: ' Udpate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: ' udpate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: 'udoaye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: 'udaote', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: ' Udpaye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: ' Udpsye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: 'ypdate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: 'udpTe', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: 'udpYe', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: 'yptade', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: 'alibe', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

Asena.addCommand({pattern: 'aoibe', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

Asena.addCommand({pattern: 'aliev', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

Asena.addCommand({pattern: 'Alive', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

Asena.addCommand({pattern: ' alive', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

Asena.addCommand({pattern: ' Alive', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

Asena.addCommand({pattern: 'xmedua', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

Asena.addCommand({pattern: 'Xmedia', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

Asena.addCommand({pattern: 'xmesia', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

Asena.addCommand({pattern: ' xmedia', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

Asena.addCommand({pattern: ' Xmedia', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

Asena.addCommand({pattern: ' Xmedua', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

Asena.addCommand({pattern: 'locaye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.locate');

}));

Asena.addCommand({pattern: 'lcoaye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.locate');

}));

Asena.addCommand({pattern: ' locate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.locate');

}));

Asena.addCommand({pattern: ' Locate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.locate');

}));

Asena.addCommand({pattern: 'lcoate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.locate');

}));

Asena.addCommand({pattern: 'imviye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

Asena.addCommand({pattern: 'inviye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

Asena.addCommand({pattern: ' invite', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

Asena.addCommand({pattern: ' İnvite', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

Asena.addCommand({pattern: ' Invite', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

Asena.addCommand({pattern: 'ingite', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

Asena.addCommand({pattern: 'imvite', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

Asena.addCommand({pattern: 'rstsrt', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

Asena.addCommand({pattern: 'reysary', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

Asena.addCommand({pattern: 'retsart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

Asena.addCommand({pattern: 'resyart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

Asena.addCommand({pattern: ' Restart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

Asena.addCommand({pattern: ' restart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

Asena.addCommand({pattern: 'resyaty', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

Asena.addCommand({pattern: 'resyary', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

Asena.addCommand({pattern: 'retart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

Asena.addCommand({pattern: 'rwstart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

Asena.addCommand({pattern: 'resyatt', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

Asena.addCommand({pattern: 'dyni', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.dyno');

}));

Asena.addCommand({pattern: 'dyjo', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.dyno');

}));

Asena.addCommand({pattern: ' dyno', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.dyno');

}));

Asena.addCommand({pattern: ' Dyno', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.dyno');

}));

Asena.addCommand({pattern: 'sydy', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.sysd');

}));

Asena.addCommand({pattern: ' sysd', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.sysd');

}));

Asena.addCommand({pattern: ' Sysd', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.sysd');

}));

Asena.addCommand({pattern: 'yagall', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.tagall');

}));

Asena.addCommand({pattern: ' tagall', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.tagall');

}));

Asena.addCommand({pattern: ' Tagall', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.tagall');

}));

Asena.addCommand({pattern: 'pjng', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

Asena.addCommand({pattern: 'ling', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

Asena.addCommand({pattern: 'pimg', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

Asena.addCommand({pattern: 'pign', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

Asena.addCommand({pattern: ' ping', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

Asena.addCommand({pattern: ' Ping', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

Asena.addCommand({pattern: ' asena', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.asena');

}));

Asena.addCommand({pattern: ' Asena', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.asena');

}));

Asena.addCommand({pattern: 'asnwa', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.asena');

}));

Asena.addCommand({pattern: 'asnea', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.asena');

}));

Asena.addCommand({pattern: 'asnwa', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.asena');

}));

Asena.addCommand({pattern: 'asnwa', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.asena');

}));

Asena.addCommand({pattern: 'ufdate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: 'udpsye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

Asena.addCommand({pattern: 'xemdia', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));
