## Thanks for Everything 
### We will always remember you..

- [Yusuf Usta](https://github.com/yusufusta)
- [@fusufs](https://t.me/fusufs)
- [@TOXIC DEVIL](https://github.com/TOXIC-DEVIL)
- [@kappithannemo](https://github.com/kappithannemo)
- [@Dinal Pabasara](https://github.com/RAVANA-SL)

<h1 align="center"><b>😈👻😇"GHOST" THE MOST POWERFUL WHATSAPP BOT 😇👻😈</b></h1>
<div align="center">

  <img src="https://telegra.ph/file/bc8b55b77fa9c1923ef48.jpg" width="200" height="230">

  <h1> 😘A modified Version of 🐺 WhatsAsena🙄 </h1>

</div>

```
Based On:
Asena; Asena UserBot,
```

## 🔎 What is WhatsAsena?
**WhatsAsena,** is a WhatsApp helper bot written by [Yusuf Usta](https://github.com/Quiec). Does not log into your account It is written on WhatsApp Web API.

## Setup
## Not For Everyone. Only Me😒!!)

😂👀💔 ඇස් කටේ බිච්
## o_O� 
## GHOST'S THE BOT FEATHERS 👻

| All Features 📢|Available ☑️|Version 🔎|
| ------------- | ------------ | ---------- |
| Admin Commands|✅|1.0|
| AFK|✅|1.2|
| AI Scanner|✅|1.1|
| Add & Kick User|✅|1.0|
| Ban & Unban User|✅|1.0|
| Carbon.sh Plugin|✅|1.4|
| Depp AI APIs|✅|1.0|
| FFMPEG Support|✅|1.6|
| Filter Support|✅|1.2|
| Greetings Support|✅|1.2|
| Group Link Generator|✅|1.0|
| Heroku Plugin|✅|1.5|
| Jid Scraper|✅|1.0|
| Location Plugin|✅|1.0|
| Lydia|✅|1.2|
| Meme Maker|✅|1.0|
| Mute & Unmute Chat|✅|1.3|
| Nekobin Plugin|✅|1.0|
| OCR Plugin|✅|1.2|
| Plugin Support|✅|1.0|
| Pre-Trained Effects|✅|3.2|
| Promote & Demote User|✅|1.1|
| Remove BG Plugin|✅|1.0|
| Scam Actions|✅|1.3|
| Scrapers|✅|1.5|
| Spammer|✅|1.4|
| Speedtest|✔|1.6|
| Sticker Maker|✅|1.0|
| Tagall|✅|1.0|
| Unvoice|✅|1.3|

### ═════💢═════
### ⚠️ Warning! 
```
Due to Userbot; Your WhatsApp account may be banned.
This is an open source project, you are responsible for everything you do. 
Absolutely, Asena executives do not accept responsibility.
By establishing the Asena, you are deemed to have accepted these responsibilities.
```

## Developers

[![Yusuf Usta](https://github.com/yusufusta.png?size=100)](https://quiec.tech) | [![Vai838](https://github.com/Vai838.png?size=100)](https://github.com/Vai838) |  [![Alperen Ç](https://github.com/xacnio.png?size=100)](https://github.com/xacnio) | [![Justin Thoms](https://github.com/justinthoms.png?size=100)](https://github.com/justinthoms) | [![CW4RR10R](https://github.com/CW4RR10R.png?size=100)](https://github.com/CW4RR10R)
----|----|----|----|----
[Yusuf Usta](https://t.me/fusufs) | [Alperen Ç](https://t.me/xacnio) | [justinthoms](https://t.me/Mr_justinthomas) | [CW4RR10R](https://github.com/CW4RR10R)
Author, Base, Bug Fixes, Modules | Author, Base, Bug Fixes, Modules | Bug Fixes, Modules, Idea | Modules, Idea | Modules

## Thanks To
- [@adiwajshing](https://github.com/adiwajshing) for coded [Baileys](https://github.com/adiwajshing/Baileys) 
- [@TOXIC DEVIL](https://github.com/TOXIC-DEVIL) special thanks for help & advancing
- [@kappithannemo](https://github.com/kappithannemo) for this coded
- [@Dinal Pabasara](https://github.com/RAVANA-SL) for help
- Translators

## License
This project is protected by `GNU General Public Licence v3.0` license.
Assign Credit to developers.Dont edit out the copyright messages!

### Disclaimer
`WhatsApp` name, its variations and the logo are registered trademarks of Facebook. We have nothing to do with the registered trademark
